package com.setecores.funcionarios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SeteCoresFuncionariosApplicationTests {

	@Test
	void contextLoads() {
	}

}
