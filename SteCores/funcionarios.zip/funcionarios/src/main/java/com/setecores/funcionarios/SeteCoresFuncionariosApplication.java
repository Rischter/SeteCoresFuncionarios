package com.setecores.funcionarios;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SeteCoresFuncionariosApplication {

	public static void main(String[] args) {
		SpringApplication.run(SeteCoresFuncionariosApplication.class, args);
	}

}
